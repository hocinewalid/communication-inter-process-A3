package PrositIPC1_Solution;

import exia.ipc.entities.PrositIPC;

public class Main{


public static void main(String[] args) {
 // On lance l'application
	
	PrositIPC.Step1 = new Etape1();
	PrositIPC.Step2 = new Etape2();
	PrositIPC.Step3 = new Etape3(); 

 PrositIPC.start();
 
 
 

 

 }
} 



